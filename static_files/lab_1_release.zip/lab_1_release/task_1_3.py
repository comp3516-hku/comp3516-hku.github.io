import numpy as np

class task_1_3:
    def __init__(self, fs=1000):
        """
        Initialize the class with a specific sampling rate.

        Args:
            fs (int): Sampling rate in Hz. Defaults to 1000Hz.
        """
        self.fs = fs
    
    def generate_agg_pure_tone(self, freq_list):
        """
        Generate an aggregated pure tone signal.

        Args:
            freq_list (list): List of frequencies of the pure tone signal (Hz).

        Returns:
            t   numpy.array: Array of timestamps in seconds. Data type must be float.
            s_t numpy.array: Array of generated signal values. Data type must be float.
        
        >>> gen = task_1_3(1000)
        >>> t, s_t = gen.generate_agg_pure_tone(freq_list=[10, 16])
        >>> np.round(t[10], 5)
        -0.99
        >>> np.round(s_t[10], 5)
        1.34484
        >>> t, s_t = gen.generate_agg_pure_tone(freq_list=[10, 20, 30, 60, 120])
        >>> np.round(t[10], 5)
        -0.99
        >>> np.round(s_t[10], 5)
        0.30902
        
        """
        t = None
        s_t = None
        # >>>>>>>>>>>>>>> YOUR CODE HERE <<<<<<<<<<<<<<<
        # todo: YOUR CODE HERE
        # >>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<
        
        t = np.array(t).astype(float)
        s_t = np.array(s_t).astype(float)
        return t, s_t