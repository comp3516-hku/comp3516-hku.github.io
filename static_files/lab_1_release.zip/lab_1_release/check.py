# --------------------------------------------------------------------------------
#
# WARNING: This file checks your solution and zips the files for submission.
# Please DO NOT CHANGE ANY PART of this file unless you are absolutely sure of
# the consequences and have consulted with the TA.
#
# --------------------------------------------------------------------------------

import doctest


from rich import print as rprint
from rich.console import Console
import builtins 
builtins.print = rprint
console = Console()

from task_1_1 import *
from task_1_2 import *
from task_1_3 import *

import argparse
import os
from datetime import datetime

import zipfile

def run_doctest(target_func):
    """
    Run doctest on the target file.

    Parameters
    ----------
    target_file : str
        The target file to run doctest on.
    """
    print(f"Running doctest on {target_func.__name__}....", end="\t")
    examples = doctest.DocTestFinder().find(target_func)
    for example in examples:
        # Run the test, capturing the results
        result = doctest.DocTestRunner(verbose=False).run(example)

        # Check if there were any failures
        if result.failed > 0:
            print(f"[red]Failures detected in {target_func.__name__}.[/red]")
            print("Verbose Output:")
            # Rerun the test with verbose output
            doctest.run_docstring_examples(target_func, globals(), verbose=True, name=target_func.__name__)
        else:
            print(f"[green] Pass [/green]")
    # doctest.run_docstring_examples(target_func, globals(), verbose=True, name=target_func.__name__)
    
    
if __name__ == "__main__":
    
    LAB_ID = 1
    
    parser = argparse.ArgumentParser(description='Check the solution and zip the files.')
    parser.add_argument("--uid", type=str, help="Your Uiversity ID. e.g. 1234567")
    args = parser.parse_args()
    
    print(f"********* Checking the solution *********")
    target_funcs = [task_1_1.generate_signal_1, 
                    task_1_1.generate_signal_2, 
                    task_1_1.generate_signal_3, 
                    task_1_2.generate_linear_chirp, 
                    task_1_2.generate_quar_chirp,
                    task_1_3.generate_agg_pure_tone]
    for target_func in target_funcs:
        run_doctest(target_func)
    
    console.print(f"********* Zipping the files *********")
    console.print(f"Your UID is {args.uid}. Is it correct? Please enter (y/n): ", end="", style="bold blue")
    if input() == "y":
        submit_files = [
            "task_1_1.py",
            "task_1_2.py",
            "task_1_3.py"
        ]
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        zip_file_name = f"{args.uid}_lab_{LAB_ID}_{timestamp}.zip"
        

        with zipfile.ZipFile(zip_file_name, "w") as zip_file:
            for file in submit_files:
                if not os.path.exists(file):
                    raise Exception(f"File {file} does not exist. Current directory is {os.getcwd()}.")
                print(f"Zipping {file}...", end="\t")
                zip_file.write(file)
                print(f"[green]Done.[/green]")
                        
        
        print(f"[green]Please submit {zip_file_name} to Moodle[/green].")
                

