from scipy.signal import butter, sosfiltfilt
from scipy.signal import savgol_filter
from scipy.signal import correlate
from scipy.fft import fft, fftfreq
from hampel import hampel
import numpy as np
import os.path as osp
import pickle
import matplotlib.pyplot as plt

class task_4_3:
    def __init__(self, data_p):
        with open(data_p, "rb") as f:
            data = pickle.load(f)
        self.ecg_data, self.fs = data["values"], data["fs"]
        
    def ecg_analysis(self):
        """
        Analyzes the ECG signal to extract the heart rate, the R-R interval and RMSSD.
        
        
        Returns:
            float: Heart rate in beats per minute (BPM).
            np.ndarray: R-R interval in seconds.
            float: RMSSD in seconds.
        
        >>> test = task_4_3("./data/task_4_3_1.pickle")
        >>> hr, rr, rmssd = test.ecg_analysis()
        >>> hr != None, np.all(rr != None), rmssd != None
        (True, True, True)
        """
        
        hr = None
        rr = None
        rmssd = None
        # >>>>>>>>>>>>>>> YOUR CODE HERE <<<<<<<<<<<<<<<
        #
        # >>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<
        hr = float(hr)
        rr = np.array(rr, dtype=np.float64)
        rmssd = float(rmssd)
        return hr, rr, rmssd
    