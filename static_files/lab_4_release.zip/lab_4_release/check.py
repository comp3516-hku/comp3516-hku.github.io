# --------------------------------------------------------------------------------
#
# WARNING: This file checks your solution and zips the files for submission.
# Please DO NOT CHANGE ANY PART of this file unless you are absolutely sure of
# the consequences and have consulted with the TA.
#
# --------------------------------------------------------------------------------


import doctest


from rich import print as rprint
from rich.console import Console
import builtins 
builtins.print = rprint
console = Console()

from task_4_1 import *
from task_4_2 import *
from task_4_3 import *

import argparse
import os
from datetime import datetime

import zipfile

LAB_ID = 4
DATA_ROOT = "./data/"

def run_doctest(target_func):
    """
    Run doctest on the target file.

    Parameters
    ----------
    target_file : str
        The target file to run doctest on.
    """
    print(f"Running doctest on {target_func.__name__}....", end="\t")
    examples = doctest.DocTestFinder().find(target_func)
    for example in examples:
        # Run the test, capturing the results
        result = doctest.DocTestRunner(verbose=False).run(example)

        # Check if there were any failures
        if result.failed > 0:
            print(f"[red]Failures detected in {target_func.__name__}.[/red]")
            print("Verbose Output:")
            # Rerun the test with verbose output
            doctest.run_docstring_examples(target_func, globals(), verbose=True, name=target_func.__name__)
        else:
            print(f"[green] Pass [/green]")
    # doctest.run_docstring_examples(target_func, globals(), verbose=True, name=target_func.__name__)
    

def collect_solution_1(data_dict):
    print(f"Collecting the solution for task 4_1 ...", end="\t")
    test_1 = task_4_1()
    try:
        data, fs = test_1.get_data()
        filtered_lp = test_1.apply_lowpass(data=data, fs=fs)
        filtered_hp = test_1.apply_highpass(data=data, fs=fs)
        filtered_bp, cf1, cf2 = test_1.apply_bandpass(data=data, fs=fs)
    except:
        raise Exception("Please check your solution for task_4_1.")
    
    data_dict["task_4_1"] = {
        "hp": {
            "filtered": filtered_hp
        },
        "lp": {
            "filtered":filtered_lp
        },
        "bp":{
            "filtered": filtered_bp,
            "cutoff1": cf1,
            "cutoff2": cf2
        }
    }
    print(f"[green]Done.[/green]")
    return data_dict

def collect_solution_2(data_dict):
    print(f"Collecting the solution for task 4_2 ...", end="\t")
    test_2 = task_4_2()
    try:
        filtered1 = test_2.apply_filter_1()
        filtered2 = test_2.apply_filter_2()
    except:
        raise Exception("Please check your solution for task_4_2.")
    
    data_dict["task_4_2"] = {
        "4_2_1": {
            "filtered": filtered1
        },
        "4_2_2": {
            "filtered": filtered2
        },
    }
    print(f"[green]Done.[/green]")
    return data_dict

def collect_solution_3(data_dict):
    print(f"Collecting the solution for task 4_3 ...", end="\t")
    data_dict["task_4_3"] = []
    for i in range(1, 11):
        file_n = f"task_4_3_{i}.pickle"
    
        file_p = osp.join(DATA_ROOT, file_n)
        test_3 = task_4_3(file_p)
        try:
            hr, rr, rmssd = test_3.ecg_analysis()
        except:
            raise Exception("Please check your solution for task_4_3.")
        data_dict["task_4_3"] += {
            file_n: {
                "hr": hr,
                "rr": rr,
                "rmssd": rmssd
            }
        }
    print(f"[green]Done.[/green]")
    return data_dict
        
    
    
if __name__ == "__main__":
    

    
    parser = argparse.ArgumentParser(description='Check the solution and zip the files.')
    parser.add_argument("--uid", type=str, help="Your Uiversity ID. e.g. 1234567")
    args = parser.parse_args()
    
    print(f"********* Checking the solution *********")
    target_funcs = [task_4_1.apply_lowpass, 
                    task_4_1.apply_highpass,
                    task_4_1.apply_bandpass, 
                    task_4_2.apply_filter_1, 
                    task_4_2.apply_filter_2, 
                    task_4_3.ecg_analysis,]
    for target_func in target_funcs:
        run_doctest(target_func)
        
    print(f"********* Collecting the solution *********")
    
    data_dict = dict().fromkeys(["task_4_1", "task_4_2", "task_4_3"])
    data_dict = collect_solution_1(data_dict)
    data_dict = collect_solution_2(data_dict)
    data_dict = collect_solution_3(data_dict)
    
    console.print(f"********* Zipping the files *********")
    console.print(f"Your UID is {args.uid}. Is it correct? Please enter (y/n): ", end="", style="bold blue")
    if input() == "y":
        answer_sheet_fn = f"{args.uid}_lab_{LAB_ID}_answer-sheet.npy"
        with open(answer_sheet_fn, "wb") as f:
            print(f"Saving the answer sheet to {answer_sheet_fn}...", end="\t")
            np.save(f, data_dict)
            print(f"[green]Done.[/green]")
        
        submit_files = [
            "task_4_1.py",
            "task_4_2.py",
            "task_4_3.py",
            answer_sheet_fn
        ]
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        zip_file_name = f"{args.uid}_lab_{LAB_ID}_{timestamp}.zip"
        

        with zipfile.ZipFile(zip_file_name, "w") as zip_file:
            for file in submit_files:
                if not os.path.exists(file):
                    raise Exception(f"File {file} does not exist. Current directory is {os.getcwd()}.")
                print(f"Zipping {file}...", end="\t")
                zip_file.write(file)
                print(f"[green]Done.[/green]")
                        
        
        print(f"[green]Please submit {zip_file_name} to Moodle[/green].")
                

