import numpy as np
import os.path as osp
import pickle
import matplotlib.pyplot as plt
from scipy.signal import correlate, find_peaks
from scipy.io import wavfile as wf

class task_3_3:
    def __init__(self, data_root="./data/") -> None:
        """
        Initializes the task_3_3 class, loading signal data from wav files.

        Attributes:
            data_root (str): The root directory where data files are stored.
            wav_fn (str): Filename for the music (task_3_3).
            wav_data (ndarray): Loaded data for the music signal.
            fs (int): Sampling frequency of the music signal.
        """
        self.data_root = data_root
        
        self.wav_fn = "task_3_3.wav"
        
        
        with open(osp.join(self.data_root, self.wav_fn), "rb") as f:
            self.fs, self.wav_data = wf.read(f)
        self.wav_data = self.wav_data.astype(np.float64)
        
    def get_tempo(self):
        """
        Calculate the beat tempo from the self.wav_data.
        The tempo range is 70-150 BPM.

        Returns:
            tempo (float64): The tempo in beats per minute (BPM).
        
        >>> test = task_3_3()
        >>> tempo = test.get_tempo()
        >>> (tempo >= 70) & (tempo <= 150)
        True
        """

        tempo = 0 
        
        # >>>>>>>>>>>>>>> YOUR CODE HERE <<<<<<<<<<<<<<<
        # TODO:
        # >>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<
        
        tempo = float(tempo)
        return tempo
    
    

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)