# --------------------------------------------------------------------------------
#
# WARNING: This file checks your solution and zips the files for submission.
# Please DO NOT CHANGE ANY PART of this file unless you are absolutely sure of
# the consequences and have consulted with the TA.
#
# --------------------------------------------------------------------------------


import doctest


from rich import print as rprint
from rich.console import Console
import builtins 
builtins.print = rprint
console = Console()

from task_3_1 import *
from task_3_2 import *
from task_3_3 import *

import argparse
import os
from datetime import datetime

import zipfile

def run_doctest(target_func):
    """
    Run doctest on the target file.

    Parameters
    ----------
    target_file : str
        The target file to run doctest on.
    """
    print(f"Running doctest on {target_func.__name__}....", end="\t")
    examples = doctest.DocTestFinder().find(target_func)
    for example in examples:
        # Run the test, capturing the results
        result = doctest.DocTestRunner(verbose=False).run(example)

        # Check if there were any failures
        if result.failed > 0:
            print(f"[red]Failures detected in {target_func.__name__}.[/red]")
            print("Verbose Output:")
            # Rerun the test with verbose output
            doctest.run_docstring_examples(target_func, globals(), verbose=True, name=target_func.__name__)
        else:
            print(f"[green] Pass [/green]")
    # doctest.run_docstring_examples(target_func, globals(), verbose=True, name=target_func.__name__)
    

def collect_solution_1(data_dict):
    print(f"Collecting the solution for task 3_1 ...", end="\t")
    test_1 = task_3_1()
    try:
        acf1 = test_1.apply_acf_pt()
        acf2 = test_1.apply_acf_pulse()
    except:
        raise Exception("Please check your solution for task_3_1.")
    
    data_dict["task_3_1"] = {
        "3_1_1": {
            "acf": acf1,
        },
        "3_1_2": {
            "acf": acf2,
        }
    }
    print(f"[green]Done.[/green]")
    return data_dict

def collect_solution_2(data_dict):
    print(f"Collecting the solution for task 3_2 ...", end="\t")
    test_2 = task_3_2()
    try:
        br1 = test_2.get_br_1()
        br2 = test_2.get_br_2()
        hr1 = test_2.get_hr_1()
        hr2 = test_2.get_hr_2()
    except:
        raise Exception("Please check your solution for task_3_2.")
    
    data_dict["task_3_2"] = {
        "3_2_1": {
            "br": br1
        },
        "3_2_2": {
            "br": br2
        },
        "3_2_3": {
            "hr": hr1
        },
        "3_2_4": {
            "hr": hr2
        }
    }
    print(f"[green]Done.[/green]")
    return data_dict

def collect_solution_3(data_dict):
    print(f"Collecting the solution for task 3_3 ...", end="\t")
    test_3 = task_3_3()
    try:
        tempo = test_3.get_tempo()
    except:
        raise Exception("Please check your solution for task_3_3.")
    data_dict["task_3_3"] = {
        "tempo": tempo
    }
    print(f"[green]Done.[/green]")
    return data_dict
        
    
    
if __name__ == "__main__":
    
    LAB_ID = 3
    
    parser = argparse.ArgumentParser(description='Check the solution and zip the files.')
    parser.add_argument("--uid", type=str, help="Your Uiversity ID. e.g. 1234567")
    args = parser.parse_args()
    
    print(f"********* Checking the solution *********")
    target_funcs = [task_3_1.apply_acf_pt, 
                    task_3_1.apply_acf_pulse, 
                    task_3_2.get_br_1, 
                    task_3_2.get_br_2, 
                    task_3_2.get_hr_1,
                    task_3_2.get_hr_2,
                    task_3_3.get_tempo]
    for target_func in target_funcs:
        run_doctest(target_func)
        
    print(f"********* Collecting the solution *********")
    
    data_dict = dict().fromkeys(["task_3_1", "task_3_2", "task_3_3"])
    data_dict = collect_solution_1(data_dict)
    data_dict = collect_solution_2(data_dict)
    data_dict = collect_solution_3(data_dict)
    
    console.print(f"********* Zipping the files *********")
    console.print(f"Your UID is {args.uid}. Is it correct? Please enter (y/n): ", end="", style="bold blue")
    if input() == "y":
        answer_sheet_fn = f"{args.uid}_lab_{LAB_ID}_answer-sheet.npy"
        with open(answer_sheet_fn, "wb") as f:
            print(f"Saving the answer sheet to {answer_sheet_fn}...", end="\t")
            np.save(f, data_dict)
            print(f"[green]Done.[/green]")
        
        submit_files = [
            "task_3_1.py",
            "task_3_2.py",
            "task_3_3.py",
            answer_sheet_fn
        ]
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        zip_file_name = f"{args.uid}_lab_{LAB_ID}_{timestamp}.zip"
        

        with zipfile.ZipFile(zip_file_name, "w") as zip_file:
            for file in submit_files:
                if not os.path.exists(file):
                    raise Exception(f"File {file} does not exist. Current directory is {os.getcwd()}.")
                print(f"Zipping {file}...", end="\t")
                zip_file.write(file)
                print(f"[green]Done.[/green]")
                        
        
        print(f"[green]Please submit {zip_file_name} to Moodle[/green].")
                

