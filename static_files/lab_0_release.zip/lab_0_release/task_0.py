import numpy as np

class task_0:
    def __init__(self):
        pass
    
    def print_hello(self):
        """
        Print "Hello, World!" to the console.
        
        Example:
            >>> gen = task_0()
            >>> gen.print_hello()
            Hello, World!
        """
        # >>>>>>>>>>>>>>> YOUR CODE HERE <<<<<<<<<<<<<<<
        # print("Hello, World!")
        # >>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<
    
    def return_numpy_array(self, arr: np.array):
        """
        Return a numpy array in np.float64 format.
        
        Params:
            arr (np.array): A numpy array to return.
        
        Example:
            >>> gen = task_0()
            >>> arr = gen.return_numpy_array(np.array([1, 2, 3, 4, 5]))
            >>> arr
            array([1., 2., 3., 4., 5.])
        """
        # >>>>>>>>>>>>>>> YOUR CODE HERE <<<<<<<<<<<<<<<
        # return arr.astype(np.float64)
        # >>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<
    
    def get_linear_array(self, start: int, end: int, step: int) -> np.array:
        """
        Generate a linear array from start to end with the given step size.
        
        Params:
            start (int): The start value of the array.
            end (int): The end value of the array.
            step (int): The step size between the values.
        
        Returns:
            np.array: The generated linear array.
        
        Example:
            >>> gen = task_0()
            >>> gen.get_linear_array(1, 2, 0.1)
            array([1. , 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9])
        """
        # >>>>>>>>>>>>>>> YOUR CODE HERE <<<<<<<<<<<<<<<
        # return np.arange(start, end, step)
        # >>>>>>>>>>>>>>>>>> Alternatively <<<<<<<<<<<<<<<<
        # return np.linspace(start, end, endpoint=False, num=int((end-start)/step))
        # >>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<
        
    
        