function addDefaultTitles() {
    var defaultTitle = "Default Title"; // Change this to your desired default title
    var slides = document.querySelectorAll('.reveal .slides section');

    slides.forEach(function(slide) {
        if (slide.querySelector('h2') === null) {
            var titleElement = document.createElement('h2');
            titleElement.textContent = defaultTitle;
            slide.insertBefore(titleElement, slide.firstChild);
        }
    });
}

// Run the function after the presentation is fully loaded
Reveal.addEventListener('ready', addDefaultTitles);
